<?php
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    
// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "wastemanagement";

// Create a database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check if the connection is successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$username = $_REQUEST['userid'];
$password = $_REQUEST['password'];


// Query to check if the user exists
$query = "SELECT * FROM details WHERE userid = '$username' AND password ='$password'";


if ($conn->query($sql) === TRUE) {
    echo "Login successfully";
} else {
    echo "Error: no user found!! <a href='login.php'>Try again</a>";
}


// Close statement and connection

$conn->close();
header("Location: home.html");
exit();
?>
