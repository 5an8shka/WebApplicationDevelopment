<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Display Data</title>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <!-- Custom CSS -->
  <style>
    /* Your custom styles here */
    body {
      font-family: 'Montserrat', sans-serif;
      background-color: #f8f9fa;
      color: #343a40;
    }

    .container {
      margin-top: 50px;
    }

    .data {
      background-color: #fff;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.1);
      margin-bottom: 20px;
    }

    .data h3 {
      color: #007bff;
    }
  </style>
</head>
<body>

  <!-- Container for displaying data -->
  <div class="container">
    <?php
    // Database connection parameters
    $servername = "localhost";
    $username = "root"; // Replace with your MySQL username
    $password = ""; // Replace with your MySQL password
    $dbname = "wastemanagement"; // Replace with your database name

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // SQL query to fetch data from the database
    $sql = "SELECT name, email, campaign FROM details"; // Replace 'your_table_name' with your actual table name
    $result = $conn->query($sql);

    // Check if there are any rows returned
    if ($result->num_rows > 0) {
        // Output data of each row
        while($row = $result->fetch_assoc()) {
            echo "<div class='data'>";
            echo "<h3>CAMPAIGN SUCCESSFULLY JOINED!</h3>";
            echo "<p>Name: " . $row["name"] . "</p>";
            echo "<p>Email: " . $row["email"] . "</p>";
            echo "</div>";
        }
    } else {
        echo "No data found.";
    }
    
    // Close connection
    $conn->close();
    ?>
     <a href="home.html" class="btn btn-warning btn-lg text-uppercase text-white"
            >Return to Home</a
          >
  </div>

  <!-- Bootstrap JS and jQuery -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
