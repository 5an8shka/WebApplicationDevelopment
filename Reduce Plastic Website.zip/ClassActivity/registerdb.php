<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "wastemanagement";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$name =$_REQUEST['name'];
$email =$_REQUEST['email'];
$phoneno =$_REQUEST['phoneno'];
$address =$_REQUEST['address'];
$userid =$_REQUEST['userid'];
$password =$_REQUEST['password'];

$sql = "INSERT INTO details (name, email, phoneno, address, userid, password)
VALUES ('$name', '$email', '$phoneno', '$address', '$userid', '$password')";

if ($conn->query($sql) === TRUE) {
    echo "Register successfully";
} else {
    echo "Error: no user found!! <a href='login.php'>Try again</a>";
}


// Close statement and connection

$conn->close();
header("Location: login.php");
exit();
?>