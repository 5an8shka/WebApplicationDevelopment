<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <style>
        .login-form {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 250px;
    height: 250px;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
    background-color: rgba(255, 255, 255, 0.5);
    backdrop-filter: blur(10px);
  }

  .login-form input[type="text"],
  .login-form input[type="password"] {
    width: 80%;
    padding: 10px;
    margin-bottom: 20px;
    border: 1px solid #ccc;
    border-radius: 3px;
  }

  .login-form input[type="submit"] {
    width: 90%;
    padding: 10px;
    background-color: #023e8a;
    color: #fff;
    border: none;
    border-radius: 3px;
    cursor: pointer;
  }
    </style>
    
</head>
<body >
 <div class="login-form">
    <center><h1>Login</h1>
    <form method="post" action="logindb.php">
        <label for="userid">User Id:</label>
        <input type="text" name="userid"><br><br>
        <label for="Password">Password:</label>
        <input type="password" name="password"><br><br>
        <hr>
        <input type="Submit" name="submit"> 
        <br>
        or
        <br>
    </form>
    <form action="register.php">
    <input type="button" name="submit" value="Register">
    </form>
</center>
  </div>

</body>
</html>
