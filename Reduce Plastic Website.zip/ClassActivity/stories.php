<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Waste Management | Home</title>
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.3/css/bootstrap.min.css"
      integrity="sha512-jnSuA4Ss2PkkikSOLtYs8BlYIeeIK1h99ty4YfvRPAlzr377vr3CXDb7sb7eEEBYjDtcYj+AjBH3FLv5uSJuXg=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
      integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100..900&family=Roboto+Slab:wght@100..900&display=swap"
      rel="stylesheet"
    />
    <link rel="stylesheet" href="style2.css">
    <style>
       body{
    background-image: url(img/b4.jpg);
    background-size: cover;
    background-repeat: no-repeat;
    background-position: center;
    
    position: relative;
      }
    </style>

  </head>
  <body>
    <div id="wrapper">
      <nav
        class="navbar navbar-expand-lg bg-transparent "
        id="mainMenu"
      >
        <div class="container">
          
          <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0 text-uppercase">
              <li class="nav-item">
                <a class="nav-link text-dark" href="home.html">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-dark" href="createcamp.html">Create Campaign</a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-dark" href="joincamp.php">Join Campaign</a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-dark" href="track.html">Track Progress</a>
              </li>
              <li class="nav-item">
                <a class="nav-link text-dark" href="stories.php"
                  >Success Stories</a
                >
              </li>
            </ul>
          </div>
        </div>
      </nav>

  <!-- Write Success Story Form -->
  <section class="write-story">
    <div class="container">
      <h2>Write Your Success Story</h2>
      <form id="successStoryForm" action="stories.php">
        <div class="form-group">
          <label for="name">Your Full Name</label>
          <input type="text" class="form-control" id="name" name="name" required>
        </div>
        <div class="form-group">
          <label for="story">Your Success Story</label>
          <textarea class="form-control" id="story" name="story" rows="5"  required></textarea>
        </div>
        <br>
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
    </div>
  </section>
<hr>
  <!-- Success Stories Section -->
  <!-- Success Stories Section -->
<section class="success-stories">
  <div class="container">
    <h2>Success Stories</h2>
    <div id="successStories">
      <?php
      // Database connection parameters
      $servername = "localhost";
      $username = "root"; // Replace with your MySQL username
      $password = ""; // Replace with your MySQL password
      $dbname = "wastemanagement"; // Replace with your database name

      // Create connection
      $conn = new mysqli($servername, $username, $password, $dbname);

      // Check connection
      if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
      }

      // SQL query to fetch data from the story table
      $sql = "SELECT name, story FROM story";
      $result = $conn->query($sql);

      // Check if there are any rows returned
      if ($result->num_rows > 0) {
          // Output data of each row
          while($row = $result->fetch_assoc()) {
              echo "<div class='story'>";
              echo "<p>" . $row["story"] . "</p>";
              echo "<p>Author: " . $row["name"] . "</p>";
              echo "</div>";
              echo "<hr>";
          }
      } else {
          echo "No stories found.";
      }

      // Close connection
      $conn->close();
      ?>
    </div>
  </div>
</section>


  <!-- Footer -->
  <footer class="footer">
    <div class="container">
      <p>&copy; 2024 Plastic Free. All rights reserved.</p>
    </div>
  </footer>

  <!-- Bootstrap JS and jQuery -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

 
</body>
</html>
