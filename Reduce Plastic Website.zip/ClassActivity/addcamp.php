<?php
// Check if the form is submitted

    // Database connection parameters
    $servername = "localhost";
    $username = "root"; // Replace with your MySQL username
    $password = ""; // Replace with your MySQL password
    $dbname = "wastemanagement"; // Replace with your database name

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
     // Set parameters
     $title = $_REQUEST['title'];
     $description = $_REQUEST['description'];
     $goal = $_REQUEST['goal'];
     $deadline = $_REQUEST['deadline'];

    // Prepare and bind parameters
   $sql="INSERT INTO campaign (title, description, goal, deadline) VALUES ('$title','$description','$goal','$deadline')";
    if ($conn->query($sql) === TRUE) {
        echo "New campaign added successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }


    // Close statement and connection
    
    $conn->close();
    header("Location: joincamp.php");
    exit();


   
?>

