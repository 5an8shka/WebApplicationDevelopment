let boxes= document.querySelectorAll(".box");
let resetbtn= document.querySelector("#reset-btn");
let turn= true;
const winpattern= [
    [0,1,2],
    [3,4,5],
    [6,7,8],
    [0,3,6],
    [1,4,7],
    [2,5,8],
    [0,4,8],
    [2,4,6]
];

boxes.forEach((box)=>{
    box.addEventListener("click",()=>{
        if(turn){
            box.innerText="X";
            turn=false;
        }else{
            box.innerText="O";
            turn=true;
        }
        box.disabled=true;
        checkWinner();
    })
});

const checkWinner=()=>{
    for(pattern of winpattern){
        let val1= boxes[pattern[0]].innerText;
        let val2= boxes[pattern[1]].innerText;
        let val3= boxes[pattern[2]].innerText;

        if(val1!=""&&val2!=""&&val3!=""){
            if(val1==val2 && val2==val3){
                showWinner(val1);
            }
        } }}

const showWinner=(winner)=>{
    setTimeout(() => {
        alert(`Winner is: ${winner}`);}, 100);
        disableBoxes();
}

const disableBoxes = () => {
    for (let box of boxes) {
      box.disabled = true;
    }
  };

  const enableBoxes = () => {
    for (let box of boxes) {
      box.disabled = false;
      box.innerText="";
    }
  };

const resetGame=()=>{
    turn = true;
    enableBoxes();
}

resetbtn.addEventListener("click",resetGame);